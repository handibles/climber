suppressPackageStartupMessages(library(dada2))

  ## jfg added for-loop to account for different runs (as notated in filenames)
  ## note : requries sourcing a sampllist

  # but is this necessary? Averaging error is of unclear importance, notwithstanding slight increase in processing

fns = list.files()
samplelist <- read.table('~/Materials/sample_run_list.txt',header=TRUE)

runs <- unique(samplelist$Run)

for (batch in runs) {
  run_fns <- fns[grepl(paste0('run',batch), fns)]   # cycle through filenames by run accession, get per-run error below, save 
  
  dadaFs <- run_fns[grepl(".dadaF.RDS", run_fns)]
  dadaRs <- run_fns[grepl(".dadaR.RDS", run_fns)]
  
  ############# For loop to extract matrices ##################       ## grabs the err_out's from the dada2-class objects (RDS), set to an err_list
  
  dadaF_list = list()
  for (sample in dadaFs){
      x = readRDS(sample)
      dadaF_list[[sample]] = x$err_out
  }
  
  dadaR_list = list()
  for (sample in dadaRs){
      x = readRDS(sample)
      dadaR_list[[sample]] = x$err_out
  }
  
  ################## Averaging Matrices ####################### ## averaging so error estimate is representative of entire 
                                                                ## run, not the first X samples used to build profile
  dadaF_avg = Reduce("+", dadaF_list) / length(dadaF_list)
  dadaR_avg = Reduce("+", dadaR_list) / length(dadaR_list)
  
     saveRDS(dadaF_avg, file=paste0("run" , batch, ".dadaF_avg.RDS") )
     saveRDS(dadaR_avg, file=paste0("run" , batch, ".dadaR_avg.RDS") )
}
   