#!/usr/bin/Rscript

library('phyloseq')
library('stringr')

phylRDS <- '/data/jamie/eoe/Materials/6_eoe_Seqtab/eoe_run1_phyloseq.RDS'
uc_output <- '/data/jamie/eoe/Materials/6_eoe_Seqtab/eoe_uc_out_Y.uchime'
outFNA <- '/data/jamie/eoe/Materials/6_eoe_Seqtab/eoe_run1_otus_uc.fna'


## write_FNA fn, mod'd from zachcp  ===========================

write_FNA <- function(x, outfile){
  FIRST = TRUE
  if (class(x) == 'phyloseq'){  # intent to be phylo with ASV in tax_table
    seqs <- unlist(lapply(tax_table(phylobj)[,8] , as.character))                # this is just sooo fucking fast
  } else {
    seqs <- colnames(x) }      # intent is to be a seqtab

    for (i in seq_along(seqs)) {
    if (i == 2)  FIRST = FALSE
    outdata = paste0(">Seq_", str_pad(i, 7, pad=0),"\n", seqs[[i]], "\n")
    if (FIRST == TRUE) {
      write(outdata,file = outfile, sep="", append = FALSE)
    } else {
      write(outdata,file = outfile, sep="", append = TRUE)
    } 
  }
  print(paste0("All records are printed to fastafile ", outfile))
}

## ====================================================

chims <- read.table(uc_output, header=FALSE, stringsAsFactors = FALSE)[,2]

# likely problems from the ASV names
phylobj <- readRDS(phylRDS)
# match sequence ASV_ID, written by 7.3.RDS_Agg
phylobj <- prune_taxa(!(taxa_names(phylobj) %in% chims) , phylobj)

# save out PHYLO
saveRDS(phylobj , gsub('.RDS', '_uc.RDS', phylRDS) )
print(paste0("Chimera-scrubbed phyloseq.RDS saved to ", gsub('.RDS', '_uc.RDS', phylRDS)))

# save out FNA
write_FNA(x = phylobj , outfile = outFNA )



# 
# ## insert UCHIME secti0on, as per CUTADAPT in D2 w/f
# 
# usearch <- "/usr/bin/usearch_64" # CHANGE ME to the cutadapt path on your machine
# system2(usearch, args = "--help") # Run shell commands from R
# 
# # what do we need? 
#   # external id'd seq for each ASV
#   # report bad seq ID and seq
#   # remove from 
# 
#   system2(cutadapt, args = c(R1.flags,
#                              R2.flags,
#                              "-n",
#                              2, # -n 2 required to remove FWD and REV from reads
#                              "-o",
#                              fnFs.cut[i],
#                              "-p", fnRs.cut[i] , fnFs.filtN[i] , fnRs.filtN[i])     ) 
# 
#   usearch_64, args = c('-uchime_ref eoe_run1_otus.fna',
#   '-db /data/jamie/ref/chimera_slayer_gold_db/rRNA16S_gold_v20110519.fasta',
#   '-uchimeout eoe_uc_out.uchime',
#   '-strand plus',
#   '-nonchimeras eoe_uc_good.fasta')
#   