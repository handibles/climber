#!/usr/bin/Rscript

# see phyloseq-tools by zachcp, and DECIPHER
#   Combines abundances and RSV's per sample into one large seqtab, assigns taxa from seqtab

# RUNMERGER: as each sample has now been processed with different error profiles, no need to keep them separate anymore
# - instead provide a switch for all runs / specific runs  -  i.e. (if !(--run==NULL), then use --run )

# incporate sample_data and phylo_tree in this also.



    # ## MAKE A TREE AND SHIT
    # 
    # # taken from the BigBoi's F1000 paper v.2 : https://f1000research.com/articles/5-1492/v2
    # library('phangorn')
    # library('DECIPHER')
    # 
    # 
    # ## DECIPHER
    # seqtab <- readRDS('../output/6_eoe_Seqtab/eoe_run1_seqtab.RDS')
    # seqs <- getSequences(seqtab)
    # names(seqs) <- seqs # This propagates to the tip labels of the tree
    # alignment <- AlignSeqs(DNAStringSet(seqs), anchor=NA, processors = 27)
    # 
    # ## Phangorn  -  hey jamie, wtf are these functions doing?
    # print('Phangorn:', \\n, 'Using Max-Likelihood, JC69 and then GTR substitution models, Neighbour-Joining, GTR .. read up!')
    # phang.align <- phyDat(as(alignment, "matrix"), type="DNA")
    # dm <- dist.ml(phang.align)
    # treeNJ <- NJ(dm) # Note, tip order != sequence order
    # fit = pml(treeNJ, data=phang.align)
    # fitGTR <- update(fit, k=4, inv=0.2)
    # fitGTR <- optim.pml(fitGTR,                             ##     < ! >  >40min!
    #                     model="GTR",
    #                     optInv=TRUE,
    #                     optGamma=TRUE,
    #                     rearrangement = "stochastic",
    #                     control = pml.control(trace = 0)
    # )
    # 
    # saveRDS(fitGTR, '../output/6_eoe_Seqtab/eoe_run1_phango.RDS')
    # saveRDS(fitGTR$tree, '../output/6_eoe_Seqtab/eoe_run1_phango_tree.RDS')
    # detach("package:phangorn", unload=TRUE)



#   #===============================================================================================================#

suppressPackageStartupMessages(library(DECIPHER))
suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(dada2))
suppressPackageStartupMessages(library(stringr))
suppressPackageStartupMessages(library(phyloseq))
suppressPackageStartupMessages(library(phyloseq.tools))
suppressPackageStartupMessages(library(docopt))

##
##    F U N C T I O N S 


## write_FNA fn   (zachcp)  ===========================

write_FNA <- function(seqtable, outfile){
  FIRST = TRUE
  seqs <- colnames(seqtable)
  for (i in seq_along(seqs)) {
    if (i == 2)  FIRST = FALSE
    outdata = paste0(">Seq_", str_pad(i, 7, pad=0),"\n", seqs[[i]], "\n")
    if (FIRST == TRUE) {
      write(outdata,file = outfile, sep="", append = FALSE)
    } else {
      write(outdata,file = outfile, sep="", append = TRUE)
    } 
  }
  print(paste0("All records are printed to fastafile ", outfile))
}


## MODIFIED combineRDSfiles fn   (zachcp)  ===========================

combineRDSfiles <- function(RDSdata,
                            tax_matrix,
                            otutableout,
                            phyloseqoutfile,
                            seqtabfile,
                            FNAoutfile){
  
  seqtab <- makeSequenceTable(RDSdata)
  saveRDS(seqtab, file = seqtabfile)                                    # save seqtab
  print(paste0("Saved SeqTab as ", seqtabfile))
  otab <- otu_table(seqtab, taxa_are_rows = FALSE)
  if (missing(tax_matrix)){                                             # use deciph tax if present
    taxtab <- tax_table(matrix(colnames(otab), ncol = 1))                    # save uniqueseqs 
    colnames(taxtab) <- "ASV"
  }
  else {
    taxtab <- tax_table(tax_matrix) 
  }
  colnames(otab) <- paste0("Seq_", str_pad(seq(ncol(otab)), 7, pad = 0))   # then flatten names (matching those from dada_to_deciph)
  rownames(taxtab) <- colnames(otab)
  ps <- phyloseq(otab, taxtab)
  saveRDS(ps, file = phyloseqoutfile)
  print(paste0("Saved phyloseq object as ", phyloseqoutfile))
  if (taxa_are_rows(ps)) {
    write.table(otu_table(ps), file = otutableout, quote = FALSE, sep = "\t")
  }
  else {
    write.table(t(otu_table(ps)), file = otutableout, quote = FALSE, sep = "\t")
  }
  print(paste0("Saved otutable as ", otutableout))
  write_FNA(seqtab, outfile = FNAoutfile)
}


## DADA into taxa fn    ====================================
# input: sample data from GlobEnv (__not__ external files) and ref.tax
# output: a tax_table'ble matrix

      ## trubshooot
      # data <- RDSdata
      # ref <- taxref
      # taxout <- NULL
      # strand <- 'top'
      # cpu <- NULL

dada_to_decipher <- function(data=RDSDATA,
                             ref=TAXREF,
                             taxout=NULL,
                             cpu=NULL,
                             ref_strand=c('top','bottom','both') ) {
  
  # data in
  seqtab <- makeSequenceTable(data)     # seqtab of readRDS files
  ref_strand <- match.arg(ref_strand)   # set arg as given, or pick first candidate

  # speculate taxonomies
  dna <- DNAStringSet(getSequences(seqtab)) # DNAStringSet from ASVs
  ids <- IdTaxa(dna, ref, strand=ref_strand, processors=cpu)
  ranks <- def_ranks # ranks of interest, set above docopts options
  
  ## make tax_table and add uniqueseqs
  taxid <- t(sapply(ids, function(x) {
    m <- match(ranks, x$rank)
    taxa <- x$taxon[m]
    taxa[startsWith(taxa, "unclassified_")] <- NA
    taxa
  }))
  taxid <- cbind(taxid,as.matrix(getSequences(seqtab)))     # add ASVs
  colnames(taxid) <- c(ranks, "ASV")
  rownames(taxid) <- paste0("Seq_", str_pad(seq(nrow(taxid)), 7, pad = 0))
  if(missing(taxout)){ 
    taxout <- 'dada_to_decipher_taxonomy.txt' }
  write.table(taxid, taxout, sep='\t')
  return(taxid)
  
}



#   #===============================================================================================================#
##

# pre-set
def_ranks <- c("domain", "phylum", "class", "order", "family", "genus", "species")

"Usage: 
agreggateRDSfiles.R [options]
Description:   Agregate RDS files of DADA output objects, and assign taxonomy via DECIPHER
Options:
--datain=<datain>            [default: .]          Path to directory of RDS files
--dataout=<dataout>          [default: .]          Output Directory
--taxref=<taxref>            [default: .]          Path to reference database
--study=<study>              [default: jfg ]       Name of the Experiment
--run=<run>                  [default: all ]       Run of interest if any, from name_format of input RDS files
--strand=<strand>            [default: top]        top, bottom, or both strands (for mixed orientation reads)
--thresh=<tresh>             [default: 50  ]       Simple length cutoff for samples: reads should be highly similar in length
--ranks=<ranks>              [default: def_ranks]  char vector of taxonomic levels i.e. desired colnames(tax_table)
#--cpu=<cpu>                  [default: NULL]       how many beasties to use: NULL (default) = use all available
#--verbose=<verbose>          [default: NULL]       verbose output, T/F
" -> doc
opts <- docopt(doc)

# check opts
datain         <- opts$datain
dataout        <- opts$dataout
taxref         <- opts$taxref
study          <- opts$study
strand         <- opts$strand
run            <- opts$run
thresh         <- opts$thresh
ranks          <- opts$ranks
# cpu            <- opts$cpu       # as below, but for 'NULL'
#verbose        <- opts$verbose    # broken, docopt quotes 'TRUE' rather than setting logical



          # ##  hack
          # datain  <- '/data/jamie/eoe/Materials/5_final/'
          # dataout <- '/data/jamie/eoe/Materials/6_eoe_Seqtab'
          # taxref  <- '/data/jamie/ref/SILVA_SSU_r132_March2018.RDS'
          # # datain  <- '/claesson/jamie/bl_jamiedata/eoe/Materials/5_final/'
          # # dataout <- '/claesson/jamie/bl_jamiedata/eoe/Materials/6_eoe_Seqtab'
          # # taxref  <- '/claesson/jamie/bl_jamiedata/ref/SILVA_SSU_r132_March2018.RDS'
          # study   <- 'eoe'
          # strand  <- 'top'
          # run     <- 1
          # thresh  <- 200
          # ranks   <- def_ranks   # slight unnecc
          # cpu     <- 20

## set working dir:
setwd(datain)

# original DECIPHER Silva_SSU_r132saved as RDS
taxref <- readRDS(taxref)              


## filter RDS by RUN and THRESH   ========================

  # <  !  >   only deals with one run
  #  insert loop / apply here to deal with different loops
  # consider making run variable a logical for merge/split all tables
  
  RDSfiles <- list.files(datain, pattern = 'RDS')  

  # need to allow for splitting,  but not enforce it
  if (!(run=='all')) {                                           # conditional for getting specific run - grow to loop through runs?
    RDSfiles <- RDSfiles[grepl(paste0('run',run), RDSfiles)]    ##  < ! >  select a specific run - C A R E F U L  , will nuke your shit if names are wrong 
    study <- paste0(study,'_run',run)          
  }
  RDSnames <- as.character(lapply(RDSfiles, function(x) strsplit(x, "_")[[1]][2]))   # *** strip 'runX_' and '_merged.RDS'  
  RDSdata <- lapply(RDSfiles, function(x) readRDS(paste0(datain , x)))
  names(RDSdata) <- RDSnames

  # loop and kick out rows (ASVs) with PUNY READS (i.e. RDSdata[[x]][sequence]) smaller than 'thresh')  - see str(RDSdata)
  if (!( is.na(thresh))) {                                    
    for (samp in 1:length(RDSdata)) {                         # samp <- 25
      RDSdata[[samp]] <- RDSdata[[samp]][ apply(RDSdata[[samp]][1], 1, function(x) nchar(x) >= thresh) , ]  # jfg, did you write this? this IS class 
    }
  }
  

## write out  ============================
  
  decip_tax <- dada_to_decipher(data = RDSdata,
                                ref = taxref,
                                taxout='/data/jamie/eoe/Materials/6_eoe_Seqtab/eoe_idtaxa_output.txt',
                                ref_strand = strand
                           )


## Combine, Write out OTUtab.txt, phyloseq, FNA & seqtab  =================
  combineRDSfiles(RDSdata=RDSdata, tax_matrix=decip_tax,
                 otutableout =     paste0( dataout,"/", study, "_otus.txt"),
                 phyloseqoutfile = paste0( dataout,"/", study, "_phyloseq.RDS"),
                 seqtabfile = paste0( dataout,"/", study, "_seqtab.RDS"),
                 FNAoutfile =  paste0( dataout,"/", study, "_otus.fna")
                 )
