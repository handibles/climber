#!/usr/bin/Rscript
## 4.4 :: learnErrors
# nbases = 1e8     : number of bases to read in
# randomize = TRUE : subset Xrandom samples (per-run) until reach nbases

## Get Runs
# if run = number(s), learn JUST that run(s) [ apply on mapping$Run == c(numbers) ]
# if run unspecified, learn for ALL runs in samplelist separately  [ apply on mapping$Run = c(uniques(mapping$Run)) ]
# if neither specified (or samplelist+NULL), learn from all samples together. [ (if.missing(run){fwd_reads <- fwd_reads} etc.]

# ==== 

## F I X   4 :: use plotErrors to record or compare erorrprofiles - pass save T/F, plot inside function 

## jfg::
  # changed from dada2::dada2 to dada2::learnErrors, dada-dependent function designed to speed things up in large datasets. learnErrors
  # produces the same error matrix (via dada) but none of the superfluous data that dada2 requires at later stages.
  # learnErrors also allows setting the number of BP used to estimate errors, and allows samples to be randomised. 
  # Thus only needs to be done once per run, rather than parallelised (set multithread = T here!). 

  # BUT NO: Benjneb points out that EE is better resolved with a larger dataset (making per-sample error profiles a bad idea X( )


## consider the effect of learning from dereplicated reads, as below  -  https://github.com/benjjneb/dada2/issues/183
  ## this link suggests the learnErrors already provides the separate error estimation (based on getting a LIST of 
  ## derep objects, or one POOLED derep object), then averages (still think thats a weird step, but shur..)

# from  work with WMI seqwed and issues in https://github.com/benjjneb/dada2/issues/183
  # learnErrors can natively distinguish between a pool/list of samples and a DEREPLICATED pool/list of samples. from
  # linked issue#183, suggestion is that a derep'd list of sampes is the better input, as keeps the abundance info
  # while only requiring one round of dereplication. Error profiles across samples are then averaged.
  
  # WMI case is unique in that each sample could happily satisfy the 10^8bp needs of learnErrors. 
  # SO  ::   derep samples first, then learnErrors on derep-list. 


# ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  ==  


suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(dada2))
suppressPackageStartupMessages(library(docopt))

"Usage: 
runDada2.R [options]

Description:   Run DADA2 on a Forward/Reverse fastq pair
Options:
--indir=<indir>                 [default: '.']    Input Directory
--outdir=<outdir>               [default: '.']    Output Directory
--samplelist=<samplelist>       [default: FALSE]  List of runs - omit for all runs
--run=<run>                     [default: NULL]   runs to process - omit for all runs
" -> doc
opts <- docopt(doc)


# # check opts
# # samplename    <- deprecated arg, as not EE'ing each sample
samplelist      <- opts$samplelist     # tells which samples for which runs
indir           <- opts$indir
outdir          <- opts$outdir
run             <- opts$run


      # # # # # ## hack!
      # # /home/jamie/R/bin/Rscript
      # # /home/jamie/RY/4.4_DADA2.error_pool.R
      # indir <- '/data/jamie/eoe/Materials/3_d2'
      # outdir <- '/data/jamie/eoe/Materials/4_error'
      # samplelist <- '~/Materials/sample_run_list.txt'
      # run    <- 1
      # # # # ##

## ====   ====   ====   ====   ====   ====   ====   ====   ====   ====   ====   ====   ====


setwd(indir)


mapping = read.table(samplelist, header=TRUE, sep="\t", row.names=1)

# interpret run argument
if (!(is.null(run)) && is.numeric(run)){
  run_list <- run[run %in% unique(mapping$Run)]
} else {
  print('generate error profile for each run seperately')
  run_list <- unique(mapping$Run) }


readPathsToError <- function(indir = indir,
                             outdir = outdir,
                             run = run){
  
        # deal with unpredicatable multithreading   ---   ?
        nthreads <- .Call(ShortRead:::.set_omp_threads, 1L)
        on.exit(.Call(ShortRead:::.set_omp_threads, nthreads))
        
        
        fwd_reads <- list.files(indir)[grepl('R1', list.files(indir))]
        rev_reads <- list.files(indir)[grepl('R2', list.files(indir))]
        samples <- sapply(fwd_reads, function(x) strsplit( x, '\\.')[[1]][2], USE.NAMES = FALSE )

        # catch all samples matching the run given (or pool together)
        if (!(samplelist == FALSE)){
          fwd_reads <- fwd_reads[ mapping[samples,] == run ]
          rev_reads <- rev_reads[ mapping[samples,] == run ]
        } else {
          print('no --samplelist provided - pool all samples for learnError')
        }
        
        # save reads matching $RUN to fqf / fqr
        fqf <- paste0( indir, '/', fwd_reads )
        fqr <- paste0( indir, '/', rev_reads )

        # arguably a BIG memory requirement. for loop/parallel? or split into differing jobs..
        derepF <- derepFastq(fqf, verbose=TRUE) # see above re: passing derep versus non-derep to learnError
        derepR <- derepFastq(fqr, verbose=TRUE)
        
        # workhorse: error profile for each RUN :: shuffle samples=TRUE, read samples until reach nbases = 1e^8
        errF <- learnErrors(fls=derepF, MAX_CONSIST = 15, verbose = TRUE, nbases = 1e8, randomize = TRUE, multithread = TRUE)                     
        errR <- learnErrors(fls=derepR, MAX_CONSIST = 15, verbose = TRUE, nbases = 1e8, randomize = TRUE, multithread = TRUE)
        
        ## format of:    runX.dadaF.RDS, runX.dadaR.RDS ; script 5_aggregate.R wil change to runX.dadaR_avg.RDS
        saveRDS(errF, file = paste0(outdir,"/run",run,".dadaF.RDS") )
        saveRDS(errR, file = paste0(outdir,"/run",run,".dadaR.RDS") )
        z <- paste0( "Saved DADA2 errorProfile as .RDS in run" , run , ".dadaF.RDS in ", outdir ) ; print(z)   # this double up due to an error
      }  


# call the new fn() for all runs:
lapply(run_list, readPathsToError(indir = indir,
                 outdir = outdir,
                 run=run )                     # lapply loops through this arg
                  )

