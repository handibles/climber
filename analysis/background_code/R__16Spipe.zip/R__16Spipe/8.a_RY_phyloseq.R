
## entire open needs to be cleaned between jfg / eoe approaches
## check the low-count samples against the runlist
## combine healthy_1 and healthy_2 if appropriate : rename CD/UC/Healthy/i/ni

## from dir with the phyloseq RDS in it
library('readr')
library('phyloseq')
library('reshape')
library('plyr')
library('ggplot2')
eoe_rds <- read_rds('./data_out/6_eoe_Seqtab/eoe.run1_run1_run1_phyloseq.RDS')

row.names(otu_table(eoe_rds)) <- gsub('-S.*','',rownames(otu_table(eoe_rds)) )

#   T A X
eoe_tax <- tax_table( read.table(file='./data_out/6_eoe_Seqtab/eoe_taxonomy.tsv',sep='\t', header=FALSE) ) # get sed'd mothur file
rownames(eoe_tax) <- eoe_tax[,1] ; colnames(eoe_tax) <- c("SeqID","Domain","Phylum","Class","Order","Family","Genus","Species") ; eoe_tax <- eoe_tax[,-1]
head(eoe_tax)

#   M A P  
## as ever, mapfile procured and edited outside of R  - the last redoubt of excel
eoe_map_full <- read.table('./raw_data/eoe_q1_mapfile.txt', header=TRUE, sep='\t', row.names = 1) 
# rownames(eoe_map_full) <- gsub(x=rownames(eoe_map_full), pattern='\\.T', replacement='-T')  # fix the row names (.T to -T), port to sampleID
# rownames(eoe_map_full) <- gsub(x=rownames(eoe_map_full), pattern='\\.1', replacement='-1')
# rownames(eoe_map_full) <- gsub(x=rownames(eoe_map_full), pattern='\\.2', replacement='-2')
# eoe_map <- eoe_map_full[rownames(otu_table(eoe_rds)),]
eoe_map <- sample_data(eoe_map_full[, -c(1,2,3)])

# # T R E E 
# # nice to know, but inclusion kicks out ~370 taxa, so abandoned until important
# eoe_tre <- read_tree('eoe.run_rooted.phylo.tre')   

## ## < ! > incorporate the unique seqs here

#  M E R G E
eoe_phy <- merge_phyloseq(otu_table(eoe_rds, taxa_are_rows = FALSE), tax_table(eoe_tax), eoe_map) #, eoe_tre)
eoe_phy
saveRDS(eoe_phy,file='eoe_phylo.RDS')

# D E S C R I P T O R S 
## margins too big?
plot(sort(sample_sums(eoe_phy)))
plot(log(taxa_sums(eoe_phy)))


# taxa are columns
write.table(otu_table(eoe_phy), file='./data_out/eoe_phy_otu.txt', sep='\t')  # so silly, but a quick workaround from phylo objects
cnts <- (read.table('./data_out/eoe_phy_otu.txt',sep='\t',header=TRUE))
cnts <- t(cnts)
# filter first, then flatten!
cnts_filt10 = cnts[ apply(cnts>0,1,sum)>=round(ncol(cnts)*0.05) , ]  # filt for ROWS >0 in at least n cols
dim(cnts_filt10)
# taxa now rows

mapping <- sample_data(eoe_phy)


# dont bother trying to cajoling taxa object, just re-read from source
#taxa <- read.table(file='C:\\Users\\Blip the Tall\\Documents\\Jamie blipping\\Dropbox\\SilentGeno\\R\\R_eoe\\6_eoe_Seqtab\\eoe_taxonomy.tsv',sep='\t', header=FALSE)
taxa <- read.table(file='~/Jamie blipping/Dropbox/SeqBiom__EoE/data_out/6_eoe_Seqtab/eoe_taxonomy.tsv',sep='\t', header=FALSE)
rownames(taxa) <- taxa[,1] ; taxa <- taxa[ , -1] ; colnames(taxa) <- c("Domain","Phylum","Class","Order","Family","Genus","Species")

save.image('data_out/eoe_Phylo.RData')

##   j f g   j u n k  --^    ## ===========================


## 1) Alpha and Beta diversity metrics
# count_table = read.csv("C://Users//Sidney//Desktop//phd//cdna_vs_dna//cdna_v2//DADA2_OUTPUT//16c_DNA_table.csv", header = T,row.names = 1, sep = ",")
# taxa =  read.csv("C://Users//Sidney//Desktop//phd//cdna_vs_dna//cdna_v2//DADA2_OUTPUT//taxonomy_cdna.csv", header = T,row.names = 1, sep = ",") ## read the mothur output into excel and set delimiter by semicolon to get columns by taxonomic rank
# mapping = read.table("C://Users//Sidney//Desktop//phd//cdna_vs_dna//cdna_v2//DADA2_OUTPUT//mapping_subset.txt", header = T,row.names = 1, sep = "\t")



cnts_filt10_prop = prop.table(as.matrix(cnts_filt10),2)
cnts_filt10_prop = cnts_filt10_prop * 100

OTU_raw = otu_table(cnts,taxa_are_rows = TRUE)
physeq_raw = phyloseq(OTU_raw)
alpha_div = estimate_richness(physeq_raw)         #  << !! >>

#######################################
require(dplyr)
alpha_div = tbl_df(alpha_div)
alpha_div = alpha_div%>%
  mutate(family = ACE/Chao1)
summary(alpha_div$family)

alpha_div = as.data.frame(alpha_div)
#this adds a column to c_alpha_div to check the ratio of Chao1 to ACE to see if read depth has affected family presence.


#PCOA
######################################
library('ape')
OTU = otu_table(cnts_filt10_prop,taxa_are_rows = TRUE)
physeq = phyloseq(OTU)
# physeq <- eoe_100

braycurtis_dist10 = phyloseq::distance(physeq,method="bray")   ##method can be changed to preferred distance metric
braycurtis_pc10_prop = pcoa(braycurtis_dist10)
# "while the distance remains euclidean, the solution equates to PCA"

biplot(braycurtis_pc10_prop)   ## ## improve this

#used to be a hacky wa of doing this here - redacted
mapping <- sample_data(eoe_100)
BrayCurt_data.df = data.frame(mapping,alpha_div,
                              "PC1" = braycurtis_pc10_prop$vectors[,1]*-1,
                              "PC2" = braycurtis_pc10_prop$vectors[,2]*-1,
                              "PC3" = braycurtis_pc10_prop$vectors[,3]
                              )
#saveRDS(BrayCurt_data.df,file="BrayCurt_data.df.RDS")
## Make an additional column 

################################################################

#alpha diversity visualistation
ggplot(BrayCurt_data.df,aes(x=Description,y=BrayCurt_data.df$Shannon,fill=Condition)) +
  geom_violin() +
  scale_fill_manual("Condition",values=c("#1e8bc3","#C30000","#ffb90f")) +
  theme_classic() +
  geom_dotplot(binaxis="y",stackdir = "center",dotsize=1,binwidth = 0.03, fill='black') +
  labs(x='Sample Conditions', y='Shannon',title='Shannon Diversity Estimates')
#violin plot with samples grouped by column of choice from mapping file


#beta diversity visualistation
colsums(BrayCurt_data.df[,PC1:PC2])
ggplot(BrayCurt_data.df,aes(x = PC1, y = PC2,color=Condition, shape=Status)) +
  stat_ellipse(aes(x = PC1,y =PC2, fill=Condition), geom="polygon",level=0) + #dupe for colours
  stat_ellipse(aes(x = PC1,y =PC2, fill=Condition, linetype=Status), geom="polygon",level=0.8,alpha=0.2) +
  geom_point() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
  panel.background = element_blank(), axis.line = element_line(colour = "grey80") ) +
  geom_line(aes(group = PatientID)) +
  scale_fill_manual("Condition",values=c("#1e8bc3",  "#C30000",  "#ffb90f")) +
  scale_color_manual("Condition",values=c("#1e8bc3",  "#C30000",  "#ffb90f") ) +
  scale_shape_manual("Status",values=c(1,17)) +
  labs(title='PC1 & PC2 B-Div') +
  theme(legend.position='bottom')
  # other pointless legend messing

#"#1e8bc3","#7bc5ea",  "#C30000","#ff9999",  "#ffb90f","#ffe099")) +
  

##Basic pcoa with points coloured by a column from the mapping file, and an ellipse also based on column of choice from mapping file.  

##############################################################


######################################
#######sample_composition boxplot############
####################################


# cnts = read.table("C://Users//Sidney//Desktop//phd//16s//uncoupling//analysis//uncoupling.txt", header = T, row.names = 1, sep = "\t")
# ##count table as generated by DADA2. Columns are samples, rows are sequences
# taxa = read.csv("C://Users//Sidney//Desktop//phd//16s//uncoupling//analysis//mothur_fixed.csv", header = T, row.names = 1)
# ##mothur output, but import into excel first and set seperators as semi colons so the different taxonomic ranks separate into different columns.
# taxa_colors = read.csv("C://Users//Sidney//Desktop//phd//16s//uncoupling//analysis//uc_fam_col.csv", header = T, row.names = 1)
# ## data frame containing the families present as rownames and corresponsing column with hex codes for colours. Colname must be "colors"

## LOT OF SWAPPING CNTS orientation

# cnts <- cnts    # cnts will be cnts
# taxa <- as.matrix(tax_table(eoe_phy))

min_median = 0.1 
##dictates what percentage of bacteria to sum into other
title = "requires cluster, colour sorting"
phylo_rank = "Family"  ## big plus to this flow: rank used can be set. #rank to be represented. Must correspond with colnames in taxa table


# Sum count table to Family level
family = data.frame(taxa[rownames(cnts),phylo_rank],cnts)
rownames(family) = NULL
colnames(family)[1] = phylo_rank

family_con = ddply(family,phylo_rank,numcolwise(sum))  ##cool, sum all matching abundances
rownames(family_con) = family_con[,1]
family_con = family_con[,-1]

family_con_prop = prop.table(as.matrix(family_con),2)
family_con_prop = family_con_prop * 100

#if there are different .*_unclassifieds in family_con_prop
rownames(family_con_prop) = gsub(".*_u","u", rownames(family_con_prop))
rownames(family_con_prop) = gsub("unclassified","Unclassified", rownames(family_con_prop))
family_con_prop = t(sapply( by(family_con_prop, rownames(family_con_prop), colSums), identity) )   ## THIS?

    ## see section molested here and then restored in intermediate versions
    ##
##
## F I L T E R  -  Establish which low aboundant taxa should be summed into Other
tobesummed = rownames(family_con_prop)[apply(family_con_prop,1,median)<min_median]

family_prop_tree = data.frame(as.character(rownames(family_con_prop)),family_con_prop)
colnames(family_prop_tree)[1] = phylo_rank
family_prop_tree[,phylo_rank] = as.character(family_prop_tree[,phylo_rank])
family_prop_tree[tobesummed,phylo_rank] = "Other"

family_con_prop_tree_summed = ddply(family_prop_tree,phylo_rank,numcolwise(sum))
rownames(family_con_prop_tree_summed) = family_con_prop_tree_summed[,phylo_rank]
family_con_prop_tree_summed = family_con_prop_tree_summed[,-1]

# Create separate taxa table for sorting by Phylum and chosen rank 
taxa_lu = unique(taxa[,c(phylo_rank,"Phylum")])
taxa_lu = taxa_lu[!taxa_lu[,phylo_rank]=="Unclassified",]
rownames(taxa_lu) = taxa_lu[,phylo_rank]

family_phyla = family_con_prop_tree_summed
family_phyla2 = data.frame(family_phyla,taxa_lu[rownames(family_phyla),])
family_phyla2[,phylo_rank] = as.character(family_phyla2[,phylo_rank])
family_phyla2$Phylum = as.character(family_phyla2$Phylum)
family_phyla2$Phylo_sum = apply(family_phyla,1,sum)
family_phyla2["Other",phylo_rank] = "Other"
family_phyla2["Other","Phylum"] = "Other"
family_phyla2["Unclassified",phylo_rank] = "Unclassified"
family_phyla2["Unclassified","Phylum"] = "Unclassified"
family_phyla3 = family_phyla2[with(family_phyla2,order(Phylum,-Phylo_sum)),]    #sort by phylum and 
family_phyla4 = family_phyla3[,!colnames(family_phyla3) %in% c("Phylum","Phylo_sum")]

## pick some colours - these not great
#fam_cols = as.character(taxa_colors[rownames(family_phyla4),"colors"])
fam_cols <- as.data.frame(c('#A51876','#1E78D2','#117878','#18A55E','#3FE491','#E43F5B','grey50','#3F91E4','#117878','#A51876','#18A55E','#D21E2C','grey50')) #'114578',
colnames(fam_cols) <- c('colors')
rownames(fam_cols) <- rownames(family_phyla4)

# Prepare ggplot2 object and relevel
data.df = melt(family_phyla4,id.vars = phylo_rank)
data.df[,"tofill"] = factor(data.df[,phylo_rank],levels=rownames(family_phyla4))
data.df$variable = factor(data.df$variable,levels = sort(levels(data.df$variable)))
data.df$condition <- factor(data.df$variable,levels = sort(levels(data.df$variable)))

#
## sort order by phylo, set taxon of interest as factors
#

ggplot(data.df, aes(x = variable, y = value, fill =  tofill)) +
  geom_bar(position = "fill",stat = "identity",width=0.9) +
  scale_fill_manual(values = as.vector(fam_cols$colors), name='Notable Families') +   #not getting called prop as a df col
  theme_classic() + 
  ggtitle(title) + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) #+
#  facet_grid(~)



#      ######      ######      ######      ######      ######      ######      ######      ######
#####   MV TO RESCUEEE   ######      ######      ######      ######      ######      ######      ######
#      ######      ######      ######      ######      ######      ######      ######      ######


ry <- eoe_phy
## S U B S E T  # why 0.23?..
prunA = genefilter_sample(ry, filterfun_sample(function(x) x >=200), A=0.23*nsamples(ry)) # different from subset used in heatmapping # (10, 0.23) misses taxa picked up by LEfSe
eoe_10 = prune_taxa(prunA, ry)
eoe_un10 = prune_taxa(!prunA, ry)

prunA = genefilter_sample(ry, filterfun_sample(function(x) x >=100), A=0.05*nsamples(ry)) # different from subset used in heatmapping # (10, 0.23) misses taxa picked up by LEfSe
eoe_100 = prune_taxa(prunA, ry)
eoe_un100 = prune_taxa(!prunA, ry)
write.table(file='ry100_otu.txt',otu_table(eoe_100), sep='\t')

eoe_rb <- transform_sample_counts(ry, function(x)x/sum(x))

prunB = genefilter_sample(eoe_rb, filterfun_sample(function(x) x >=0.1), A=3) # arbitrary rel.abundance cutoff: >2%  #,A=0.23*nsamples(eoe_rb))
eoe_01 = prune_taxa(prunB, eoe_rb)
eoe_un01 = prune_taxa(!prunB, eoe_rb)    # N O T E: negation of logical vector with prepending '!' !!

###   M E L T I E S
# + geom_bar(aes(color=CATEG, fill=CATEG), stat ="identity", position="dodge")
## Melt, unify, and send to one dataframe object
z.rm3 <- psmelt(eoe_01)
## get around intractable huge melt of 'other' by setting and nuking a copy of z.rm3
Seq_Dummy <-c('ID_Other','D_Other','P_Other','C_Other','O_Other','F_Other','G_Other')   # 'S_Other'
taxa <- c('SeqID','Domain','Phylum','Class','Order','Family','Genus')   # ,'Species'
Abundance <- 1-sample_sums(eoe_01)     # can check that order is correct: rownames(z.rmX)==names(sample_sums(eoe_01))
Sample <- names(Abundance)
OTU <- 'Seq_dummy'
z.rmY <- as.data.frame(Seq_Dummy) ; rownames(z.rmY) <- taxa
z.rmX <- cbind(OTU,Sample,Abundance,sample_data(ry),t(z.rmY))        # AMAZED with self that this works
# wow j

# # sort mv_un02
# z.rm4 <- z.rm4[with(z.rm4, order(Kingdom, Phylum, Class, Order, Family, Genus)), ]
# #plot the agglomerated SVs for reference of phylum abundance
# ## pool all non->2% to dummy phylum, append to bottom of melted frame 
# z.rm4$Kingdom <- c('D: Misc')
# z.rm4$Phylum <- c('P: Misc')
# z.rm4$Class <- c('C: Misc')
# z.rm4$Order <- c('O: Misc')
# z.rm4$Family <- c('F: Misc')
# z.rm4$Genus <- c('G: Misc')
# z.rm4$Species <- c('Sp: Misc')
# #z.rm4$UniqueSeq <- c('SV: Misc')
z.rm5 <- rbind(z.rm3, z.rmX)
colnames(z.rm5)

## C O M B O   b y   S e q V a r  -  more space - favoured plot
ggplot(z.rm5, aes(x=Sample,y=Abundance, fill=SeqID)) +
  facet_grid(~Gender,scales='free_x',space='free') +                                  # scale/size control
  theme_classic() +
  geom_bar(aes(fill=SeqID), stat ="identity", position="stack",  colour="black") +
  theme(strip.text.x = element_text(size = 12), strip.text.y = element_text(size = 9)) +   # bigger
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) +  # rotate
#  scale_fill_manual(values = as.vector(fam_cols$colors), name='Makes None, Gives None') +   #not getting called prop as a df col
  #  scale_fill_manual(values = (c(sort(z.col1), (z.col2)))) +  #improve SV differentiation #c(z.col42[1:37]) , 
#  theme(panel.background = element_rect(fill='white', colour='grey70')) +
#  theme(panel.grid.major.y = element_line(colour='grey75', size = 0.2)) +                               # horiz lines 1
#  theme(panel.grid.minor.y = element_line(colour='grey85', size = 0.1)) +                               # horiz lines 2
#  theme(panel.grid.major.x = element_blank()) +                                             # rm vert lines
  ggtitle("WELL HOLLLEEE SHEEET") + 
  theme(legend.position="none")
  

#########################################


#########################################
####Metagenme Seq for differential abundance####
#########################################


library(metagenomeSeq)

## equally could use the phylo to metagenomeseq connection, but flow should be either RELIANT or INDEPENDENT, and not a mixture.
cnts <- as.data.frame(cnts)
mapping <- as.data.frame(as.matrix(eoe_map))   #remove phylo-formatting
taxa = read.table(file='/home/jfg/Dropbox/SeqBiom__EoE/6_eoe_Seqtab/eoe_taxonomy.tsv',sep='\t', header=F, row.names = 1)
colnames(taxa) <- c('Domain','Phylum','Class','Order','Family','Genus','species')

##make sure mapping file and count table match up
cnts_filt10 = cnts[apply(cnts>0,1,sum)>=round(ncol(cnts)*0.05),]    # match with filtering above
subgroup = rownames(cnts_filt10)
taxa_filt = taxa[rownames(taxa) %in% subgroup,]

## need to sort the data for some reason, 'featureNames differ between assayData and featureData'
taxa_filt   <- taxa_filt[sort(rownames(taxa_filt)),]
cnts_filt10 <- cnts_filt10[sort(rownames(cnts_filt10)),]

OTUdata = AnnotatedDataFrame(taxa_filt)
phenotypeData = AnnotatedDataFrame(mapping)

mgs_obj = newMRexperiment(cnts_filt10, featureData = OTUdata, phenoData = phenotypeData)

# P = cumNormStatFast(meta)  ## no idea how/why this changed, but it did
P = cumNormStat(mgs_obj)    # changed from cumNormStat**Fast**
mgs_obj = cumNorm(mgs_obj, p = P)

############################### ADAM

###IBD vs Healthy     ## CHANGE CD TO IBD, Healthy to None
#mgs_obj_cd_h = mgs_obj[,(pData(mgs_obj)$Disease == "CD" | (pData(mgs_obj)$Disease == "Healthy"))]
mgs_obj_cd_h = mgs_obj[,(pData(mgs_obj)$Disease == "IBD" | (pData(mgs_obj)$Disease == "None"))]
#Here we design the experiment. the $Disease in this case, has to match a column in the mapping file. And the two variables have to be values within that column.

mgs_obj_cd_h = filterData(mgs_obj_cd_h, present = round(ncol(cnts_filt10)*0.1), depth = 1000) 
#filtering for OTU presence across the the samples, and read depth within the samples.

mgs_obj_cd_h <- cumNorm(mgs_obj_cd_h, p = 0.5)
pd <- pData(mgs_obj_cd_h)
mod <- model.matrix(~Disease, data = pd)
CD_healthy = fitFeatureModel(mgs_obj_cd_h, mod)
cd_h_comp_p=MRfulltable(CD_healthy,adjustMethod = "BH",number=length(CD_healthy$pvalues))
table(cd_h_comp_p$adjPvalues < 0.05)

sig_samples_CD = cd_h_comp_p[(cd_h_comp_p[,13]<0.05),]
      
## Y'BASIC
# plot(sig_samples_CD$logFC, -log10(sig_samples_CD$adjPvalues),xlim=c(-2, 2), ylim=c(0, 10),xlab="log2 fold change", ylab="-log10 p-value")

## PLOT MGS
# ideal to have all the different comparisons legibly plotted in one facet grid.
# colour dots
sig_samples_CD2 <- cbind(sig_samples_CD, as.data.frame(tax_table(eoe_phy)[rownames(sig_samples_CD),'Phylum']))

# size=CSS abundance/quartile
ggplot(sig_samples_CD2, aes(x=logFC, y=-log10(sig_samples_CD$adjPvalues))) + #,  colour=z.col57
  geom_point(alpha=0.8, size=5, aes(colour=factor(sig_samples_CD2$Phylum))) +  # make size informative
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
  panel.background = element_blank(), axis.line = element_line(colour = "grey80") ) +
  theme_classic() +
  # theme(legend.position = "none") +
  xlim(c(-2, 2)) + ylim(c(0, 15)) +
  xlab("log2 fold change") + ylab("-log10 p-value")





      # # # # # # #
       # # # # # #
      # # # # # # #
       # # HERE! # 
      # # # # # # #
       # # # # # #
      # # # # # # #

