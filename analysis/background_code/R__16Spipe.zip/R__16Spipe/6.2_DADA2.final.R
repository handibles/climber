#!/usr/bin/env Rscript

## Call for 6.2_final:
# do echo /usr/bin/Rscript ~/Dropbox/SilentGeno/R/R_RY/6.2_DADA2.final_r2_looseMerge.R 
  # --forwardReadpath ~/data/RY/Materials/3_d2/d2.$i.R1.fastq 
  # --reverseReadpath ~/data/RY/Materials/3_d2/d2.$i.R2.fastq 
  # --samplename $i 
  # --outdir ~/data/RY/Materials/5_final 
  # --samplelist ~/Materials/sample_run_list.txt 
  # >> ~/Materials/step_6_final.R ;

## call assumes error profiles are in ././Materials/4_error, assigned below

suppressPackageStartupMessages(library(docopt))

"Usage: 
runDada2.R [options]

Description:   Run DADA2 on a Forward/Reverse fastq pair
Options:
--forwardReadpath=<forwardpath>                 Forward FastQ of paired end
--reverseReadpath=<reversepath>                 Forward FastQ of paired end
--samplename=<samplename>                       SampleName
--outdir=<outdir>               [default: '.']  Output Directory
--samplelist=<samplelist>                       List of Samples and their run
" -> doc
opts <- docopt(doc)

# check opts
fqf             <- opts$forwardReadpath
fqr             <- opts$reverseReadpath
samplename      <- opts$samplename
outdir          <- opts$outdir
samplelist    	<- opts$samplelist

# # HACK # sUC72i sUC77a sUC67a sCD52a sHT56-1
# fqf             <- '/data/jamie/Materials/3_d2/d2.sUC67a.R1.fastq'
# fqr             <- '/data/jamie/Materials/3_d2/d2.sUC67a.R2.fastq'
# samplename      <- 'sUC67a'
# outdir          <- '/data/jamie/Materials/5_final'
# samplelist    	<- '~/Materials/SIRG_sample_run_list.txt'

print(fqf)

suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(dada2))

# deal with unpredicatable multithreading
nthreads <- .Call(ShortRead:::.set_omp_threads, 1L)
on.exit(.Call(ShortRead:::.set_omp_threads, nthreads))

# get the run for this sample - decides error parameter and file output
mapping = read.table(samplelist,header=TRUE,sep="\t",row.names=1)
run = mapping[samplename,"Run"]

## assign location of the error profiles
err_path <- paste0( strsplit(outdir, '5_final'), '4_error')
print( paste0('taking error profile for run ', run, 'from ', err_path, ' for sample ', samplename) )


## E R R O R   P R O F I L E S
  # several thoughts on this. 
  # 0 Default is to agglomerate samples until thresh reached, then use to make a profile per run
  # 1 RY method (ZCP method?) was to error profile PER SAMPLE (dada2_4), then average all to a single profile (dada2_5). 
  # 2 jfg method to learnErrors on randomised subset of samples, as better resolved with a larger dataset. Although per-sample 
  #   profiles would be/is nice, the risk of applying a poorly resolved profile to lower samples would exacerbate their situation 
  #   further - as such, a return to an agglomerated profile. BUT THATS BORRRRRRING. But also removes requirement for dada2_5
  # ? Consider: if (sample_size > x) {learnError(samplewise)} else { use run_avg}

  # errorParamsF <- readRDS( paste0(err_path,"/run1.dadaF_avg.RDS") ) # averaged Error profiles
  # errorParamsR <- readRDS( paste0(err_path,"/run1.dadaR_avg.RDS") )
  # errorParamsF <- readRDS( paste0(err_path,'/run',run,'.',samplename,'.output_dadaF.RDS'))   # make sure to READ the RDS, not just assign path
  # errorParamsR <- readRDS( paste0(err_path,'/run',run,'.',samplename,'.output_dadaR.RDS'))
  errorParamsF <- readRDS( paste0(err_path,"/run", run , ".dadaF_avg.RDS") ) # averaged Error profiles
  errorParamsR <- readRDS( paste0(err_path,"/run", run , ".dadaR_avg.RDS") )

    
# dereplicate  -  though done already for 4.4_ErrorPool?
derepF <- derepFastq(fqf, verbose=TRUE)
derepR <- derepFastq(fqr, verbose=TRUE)

#remove file, perform dada, CHECK BIMERA HERE, and merge.  # selfConsist to false now, as use errorParam/avg_error from learn & average errors
dadaF <- dada(derepF, err=errorParamsF, errorEstimationFunction=loessErrfun, selfConsist = FALSE)
dadaR <- dada(derepR, err=errorParamsR, errorEstimationFunction=loessErrfun, selfConsist = FALSE)

  ## here - check if the average error is a better fit / investment

bimFs <- isBimeraDenovo(dadaF)
bimRs <- isBimeraDenovo(dadaR)
mergers <- mergePairs(dadaF, derepF, dadaR, derepR, returnRejects = TRUE, maxMismatch = 2, minOverlap = 45, verbose = TRUE)  #def :: MM=0, OL=20
mergers.nochim <- mergers[!bimFs[mergers$forward] & !bimRs[mergers$reverse],]

##
##   insert UCHIME here? No need to use abundance data, as you wouldn't do it anyway with a FNA file
##

saveRDS(mergers.nochim,  file = paste0(outdir,"/","run",run,'_',samplename,"_merged",".RDS"))

save.image(file = paste0(outdir,"/","run",run,'_',samplename,"_6final",".RData"))   # can't make a sequence table a this point, as doing this on a per-sample basis, save the merger file instead. 


