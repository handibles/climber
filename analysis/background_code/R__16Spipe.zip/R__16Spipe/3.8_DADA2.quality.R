#!/usr/bin/Rscript

## from MV flow - doesn't work and aborts script
#plotQualityProfile(fnFs[1:15],fnRs[1:15])

# # setting the lib path for rscript - still stuck at 3.4 not 3.5
# # https://stackoverflow.com/questions/27673000/rscript-there-is-no-package-called
# .libPaths(c("/home/jfg/R/x86_64-pc-linux-gnu-library/3.5", .libPaths()))

suppressPackageStartupMessages(library(docopt))
suppressPackageStartupMessages( library(dada2) ) 
suppressPackageStartupMessages( library(ShortRead) ) 
#suppressPackageStartupMessages( library(ggplot2) ) # kaput!
#suppressPackageStartupMessages( library(phyloseq) ) 
    
"Usage:
fastqPairedFilter.R [options]

Description:   uses DADA2's filter on paired reads
Options:
--samplename=<samplename>                       SampleName
--inpath=<inpath>                 [default: '.']  Input Directory
--outpath=<outpath>               [default: '.']  Output Directory
" -> doc
opts <- docopt(doc)

# check opts
samplename       <- opts$samplename
outpath          <- opts$outpath
inpath           <- opts$inpath

          # # # # jfg hack
          # samplename      <- 'trimmed_6PRE-S120'
          # outpath          <- '/data/jamie/eoe/Materials/3_d2'
          # inpath           <- '/data/jamie/eoe/Materials/2_trimmed'

setwd(inpath)
fnFs <- paste0(inpath,'/',samplename,'.R1.fastq')
fnRs <- paste0(inpath,'/',samplename,'.R2.fastq')

  ## viz bit missing - now   K A P U T 

###### Quality filtering and trimming of the reads ##########
filtFs <- paste0(outpath,'/d2.',gsub( 'trimmed_', '', samplename),'.R1.fastq')
filtRs <- paste0(outpath,'/d2.',gsub( 'trimmed_', '', samplename),'.R2.fastq')

# all our lovely work making lists of lists of output now unnecessary

# ask benjneb for a less authoritarian length filter method?
##could also make our own
fastqPairedFilter( 
  	fn= c(fnFs, fnRs) ,
  	fout= c(filtFs, filtRs) ,
  	maxN=0 ,
  	maxEE=c(3,4) ,    
  	compress=FALSE ,
  	verbose=TRUE ,
  	minLen = c(150,150),
  	trimLeft=c(0, 0),           # base on TRIMMO ouput - necess?
    truncLen=c(200,200) 				# see FASTQC:Sequence Length Distribution - need to aim slightly shorter than trimmomatic [CROP + TRAILING]
    )
#   	truncQ=c(2,2) ,                # truncQ at default - can cause HUGE loss

## parameter NOTES::
  # tuncLen interaction with TRIMMMOMATIC crucial - setting CROP gives max length, then affected by TRAILING etc.; arbitrarily shorter.
  # Trimmomatic removes crap from the end, but bad ends might make merging impossible. If TRIMMO too erratic, consider just using DADA2

# ## DEACTIVEATE because you never update it   -   be aware of settings used
# print(paste("Filtering and trimming complete of",samplename," maxEE=(3,6), minLen=(150,130), truncQ=2. No: truncLen, trimLeft."))
quit('no')

