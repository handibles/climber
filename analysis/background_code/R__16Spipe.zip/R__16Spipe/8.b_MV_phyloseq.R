#! /usr/bin/Rscript

##   P R I M E 
# load.image('phyloforeward.RData')
# install.packages('tidyr')
# library('DESeq2')
# library('heatmaply')
library('phyloseq')
library('ggplot2')
library('tidyr')
library('vegan')
library('scales')

----

eoe_rds <- readRDS('./output/6_eoe_Seqtab/eoe_run1_phyloseq.RDS')
rownames(otu_table(eoe_rds)) <- gsub('-S.*','',rownames(otu_table(eoe_rds)) )

#   T A X
## 7.3 puts the UniqSeqs in a seqtab, but not in taxonomy - fix!
tax_table(eoe_rds)
    
    ## not necess if contained in phyloseq.RDS via 7.3
    # # eoe_tax <- tax_table( read.table(file='./output/Materials/6_eoe_Seqtab/eoe_taxonomy.tsv' , sep='\t' , header=FALSE) ) # get sed'd mothur file
    # eoe_tax <- tax_table( read.table(file='./output/Materials/6_eoe_Seqtab/dada_to_decipher_taxonomy.txt' , sep='\t' , header=FALSE) ) # get IdTaxa file
    # rownames(eoe_tax) <- eoe_tax[,1] ; colnames(eoe_tax) <- c("SeqID","Domain","Phylum","Class","Order","Family","Genus","Species","ASV") ; eoe_tax <- eoe_tax[,-1]
    # head(eoe_tax)

  
#   M A P  -  as ever done outside R: bash or excel
eoe_map_full <- read.table('./input/eoe_q1_mapfile.txt', header=TRUE, sep='\t', row.names = 1) 
eoe_map <- sample_data(eoe_map_full[, -c(1,2,3)])

    # # T R E E 
    # # nice to know, but inclusion kicks out ~370 taxa, so abandoned until important
    # eoe_tre <- read_tree('eoe.run_rooted.phylo.tre')   


#  M E R G E
#eoe_phy <- merge_phyloseq(otu_table(eoe_rds, taxa_are_rows = FALSE), tax_table(eoe_tax), eoe_map) #, eoe_tre)   # pre decipher
eoe_phy <- merge_phyloseq(otu_table(eoe_rds, taxa_are_rows = FALSE), tax_table(eoe_rds), eoe_map) #, eoe_tre)
eoe_phy
sample_data(eoe_phy)$'SeqDepth' <- sample_sums(eoe_phy)
sample_data(eoe_phy)$'OrigID' <- eoe_rds_OrigID
saveRDS(eoe_phy,file='./output/6_eoe_Seqtab/eoe_o_t_s_phylo.RDS')

eoe <- eoe_phy


# D E S C R I P T O R S 
## margins too big?
bad <- subset_samples(eoe , sample_sums(eoe) < 5000)
plot( sort(sample_sums(bad)), ylab = 'Total Reads per Sample', xlab = 'Sample' , ylim = c(0,8000), type = 'n' , main = 'Sequencing depth with speculative cutoffs' )
abline( h=c(1000) , lty=2, col='grey25' ) ; abline( h=c(2000) , lty=2, col='grey65' ) ; abline( h=c(3000) , lty=2, col='grey85' )
axis(4, at=c(1000,2000,3000), col= 'skyblue3', las=0)
points(sort(sample_sums(bad)), cex = 1.5, col = "skyblue3", pch = 1, lwd = 2)
text(sort(sample_sums(bad)), labels = names(sort(sample_sums(bad))), pos=1, offset = -3, cex=0.9 , srt=90 )

plot(log(taxa_sums(eoe)))



# S U B S E T T I N G
prunA = genefilter_sample(eoe, filterfun_sample(function(x) x >=200), A=0.23*nsamples(eoe)) # different from subset used in heatmapping # (10, 0.23) misses taxa picked up by LEfSe
eoe_10 = prune_taxa(prunA, eoe)
eoe_un10 = prune_taxa(!prunA, eoe)

## T R A N S F O R M   -   R E L . B U N
eoe_rb <- transform_sample_counts(eoe, function(x)x/sum(x))
## T R A N S F O R M   -   H E L L I N G E R
## hellinger of abund_value_i is the SQRT( abund_value_i / sum_all_abunds_site_j)
eoe_h<-transform_sample_counts(eoe, function(x) sqrt(x/sum(x)))   

  
----
    
##   S E Q U E N C E   L E N G T H S - infer quality of identity

## need the uniqueseqs
    
pdf('eoe_distribution of sequences.pdf')

  hist(as.vector(apply( tax_table(eoe)[,8], 1, function(x) nchar(x) )),main='histogram of all SV lengths')
  hist(as.vector(apply( tax_table(subset_taxa(eoe,domain=='Bacteria'))[,8], 1, function(x) nchar(x) )),main='histogram of Bact SV lengths')
  hist(as.vector(apply( tax_table(subset_taxa(eoe,domain=='Archaea'))[,8], 1, function(x) nchar(x) )),main='histogram of Arch SV lengths')
  hist(as.vector(apply( tax_table(subset_taxa(eoe,domain=='Eukaryota'))[,8], 1, function(x) nchar(x) )),main='histogram of "Euk" SV lengths')
  ## Eukaryota seqs are alll over the place! That one Archaeal seq ~230 (M'bacterium, total abundance of 5) doesn't look great either.
  taxa_sums(subset_taxa(eoe,Domain=='Eukaryota'))   # 2902 in total, but first 15 comprise 2039.
  sum(taxa_sums(subset_taxa(eoe,Domain=='Eukaryota'))[1:30])
  tax_table(subset_taxa(eoe,Domain=='Eukaryota'))[1:30,1:6]          # empty taxa you dope
  ## see euk specific plot later
  z.hieuk <- names(taxa_sums(subset_taxa(eoe,Domain=='Eukaryota')))[1:30]
  z.hieuk <- prune_taxa(z.hieuk, eoe) ; sum(sample_sums(z.hieuk)) ; plot_bar(z.hieuk,fill='UniqueSeq') +
  theme(legend.position="none") +
  facet_grid('~Description',scales='free_x',space='free_x')
rownames(tax_table(z.hieuk))
dev.off()


pdf('eoe_dada_phylo_rc.pdf',width=10, height=7.5)



###   P L O T T I N G

# C O L O U R S   -   B Y   S E Q V A R
# more illustrative to assign a randomised colour vector of the correct length to catch all SVs
library(scales,RColorBrewer)
z.col <- hue_pal()( nrow(tax_table(eoe_01)) )  ;  z.col1 <- sample(z.col1, nrow(tax_table(eoe_01)) )
z.col1 <- hue_pal(l=55, c=80)( nrow(tax_table(eoe_01)) )  ;  z.col1 <- sample(z.col1, nrow(tax_table(eoe_01)) )
z.col2 <- hue_pal(l=50, c=85)( nrow(tax_table(eoe_un01)) )  ;  z.col2 <- sample(z.col2, nrow(tax_table(eoe_un01)) )
show_col((z.col)[1:37])
# diversity metrics: 
hist(as.vector(apply( tax_table(eoe)[,8], 1, function(x) nchar(x) )),main='histogram of all SV lengths (<350 trimmed)')
plot_richness(eoe, x = "Description",
               color = "SeqDepth",
               shape = 'Description',
               measures=c('Observed',
                          'Shannon',
                          'InvSimpson')
               ) +
  geom_boxplot() +
  geom_jitter(size=4, width = 0.08, height = 0.08) +
  scale_shape_manual(values = c(17, 15, 16, 18,17, 15, 16, 18,17, 15, 16, 18)) +
  scale_fill_distiller(palette='Spectral') +
  theme_classic() +
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) + 
  theme(panel.grid.major.x = element_line(colour='grey55', size = 0.2))
  


## B A R   C H A R T S
# dont need grid lines now?
# bw theme?
plot_bar(eoe,'ID',fill='Phylum', title = "All \(June\) samples") +
  theme_classic() +
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) +     # rotate
  facet_grid(~Description,scales='free_x',space='free_x')
  

sample_variables(eoe)
plot_bar(eoe,'Description',fill='Phylum',title='hey now') +
  facet_grid(~Description,scales='free_x',space='free_x') +
  theme_classic()
  # scale_fill_manual(values = z.col42)

plot_bar(eoe_rb,'ID',fill='Phylum',title='title') +
  facet_grid(~Description,scales='free_x',space='free_x')

plot_bar(eoe_rb,'TREATMENT',fill='UniqueSeq',title='MV Relative Read Abundance - Decorative Purposes') +
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) +     # rotate
  facet_grid(~Description,scales='free_x',space='free_x') +
#  scale_fill_manual(values=z.col) +
  theme_classic() +
  theme(legend.position="none")

  # ## PHYLOGENETICS
  # # tree composed in RAXML-ng
  # # does subsetting frack the tree?
  # # pdf('eoe_trees.pdf')
  # plot_tree(eoe_orig, color = 'Phylum',title = 'RAXMLng Tree of MV (2444 SVs)', ladderize = TRUE) + theme(legend.position="none")
  # plot_tree(eoe, color = 'Phylum', title='RAXMLng Tree of MV length filtered (>350bp, 2300 SVs)')
  # plot_tree(eoe_10, color = 'Phylum', title = 'RAXMLng Tree of MV >10reads in 50% prevalence (197 SVs)')
  # # dev.off()

###   M E L T I E S
# + geom_bar(aes(color=CATEG, fill=CATEG), stat ="identity", position="dodge")
## Melt, unify, and send to one dataframe object
z.rm3 <- psmelt(eoe_01)
z.rm4 <- psmelt(eoe_un01)
# sort eoe_un02
z.rm4 <- z.rm4[with(z.rm4, order(Domain, Phylum, Class, Order, Family, Genus)), ]
#plot the agglomerated SVs for reference of phylum abundance
## pool all non->2% to dummy phylum, append to bottom of melted frame 
z.rm4$Domain <- c('D: Misc')
z.rm4$Phylum <- c('P: Misc')
z.rm4$Class <- c('C: Misc')
z.rm4$Order <- c('O: Misc')
z.rm4$Family <- c('F: Misc')
z.rm4$Genus <- c('G: Misc')
z.rm4$Species <- c('Sp: Misc')
#z.rm4$UniqueSeq <- c('SV: Misc')
z.rm5 <- rbind(z.rm3, z.rm4)


## C O M B O   b y   S e q V a r  -  more space - favoured plot
ggplot(z.rm5, aes(x=TREATMENT,y=Abundance,fill=UniqueSeq)) +
  #  facet_grid(Phylum+Class+Order+Family+Genus~Description,scales='free_x',space='free') +                                  # scale/size control
  facet_grid(Phylum+Genus~Description,scales='free',space='free') +                                  # scale/size control
  geom_bar(aes(fill=UniqueSeq), stat ="identity", position="stack",  colour="black") +
  theme(strip.text.x = element_text(size = 12), strip.text.y = element_text(size = 9)) +   # bigger
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) +  # rotate
  scale_fill_manual(values = (c(sort(z.col1), (z.col2)))) +  #improve SV differentiation #c(z.col42[1:37]) , 
  theme(panel.background = element_rect(fill='white', colour='grey70')) +
  theme(panel.grid.major.y = element_line(colour='grey75', size = 0.2)) +                               # horiz lines 1
  theme(panel.grid.minor.y = element_line(colour='grey85', size = 0.1)) +                               # horiz lines 2
  theme(panel.grid.major.x = element_blank()) +                                             # rm vert lines
  ggtitle("Major ASVs (Rel.Ab >1%, note variable scale)") + theme(legend.position="none")

ggplot(z.rm5, aes(x=TREATMENT,y=Abundance,fill=Genus)) + 
  geom_bar(aes(fill=Genus), stat ="identity", position="stack",  colour="black") + 
  facet_grid(Class+Order+Family~Description,scales='free',space='free') + 
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) + 
  ggtitle("DW SLV OTUs with Rel.Abundances above 2% by Genus/Order/Class") +
  theme(legend.position="none") 


## Ladies and Gentlemen; THE ARCHAEA!
# re-scale colours to length of SVs in Archaea
z.colA <- sample(z.col, nrow(tax_table(subset_taxa(eoe_rb,Domain=='Archaea'))) )
z.rmA <- psmelt(subset_taxa(eoe_rb,Domain=='Archaea'))
ggplot(z.rmA, aes(x=TREATMENT,y=Abundance,fill=z.col)) +
  geom_bar(aes(fill=Genus), stat ="identity", position="stack",  colour="black") +
  facet_grid(Order+Genus~Description,scales='free',space='free_x') +
  theme(strip.text.x = element_text(size = 12), strip.text.y = element_text(size = 11)) +      # biggerness
  theme(strip.text.y = element_text(angle = 0), axis.text.x = element_text(angle = 270)) +     # rotate
  ggtitle("MV Archaeal SVs by Class:Genus")  + theme(legend.position="none")
## ...   *clap*,     *clap*.


# ## C O M B O M I N O R S 
# # deleted, think of a better way
 



### O R D I N A T E
plot_ordination(eoe,ordinate(eoe,'NMDS',distance='bray'),
                color='Description', shape='situ', title='NMDS(B-C) of MV - Samples',
                label='null', type='samples')
plot_ordination(eoe,ordinate(eoe,'CCA'), #,formula= (~'Acetic.acid')
                color='Phylum', shape='Description', title='CCA of MV - Separating Samples by Community Structure', type='split') #+ 

plot_ordination(eoe, ordinate(eoe, 'CCA', formula=(~H2 )), #+ CO2
                color='nominal.rate', shape='Description', title='CCA of MV - H2', type='samples') #+ 

plot_ordination(eoe_h,ordinate(eoe,'DCA'),#,formula= (~'Acetic.acid')),
                color='SeqDepth', shape='Description', title='CCA of MV - Samples by SeqDepth - No obvious clustering by coverage', type='samples') +
  scale_shape_manual(values = c(15, 16, 17, 18)) +
  geom_point(size=5)


dev.off()
# rm(list=ls(pattern='z.'))
